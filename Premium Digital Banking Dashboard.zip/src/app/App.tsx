import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  BarChart, Bar, AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from "recharts";
import {
  LayoutDashboard, CreditCard, ArrowLeftRight, Wallet, User, ShieldCheck,
  LogOut, Bell, Search, Eye, EyeOff, ArrowDownLeft, CheckCircle2, XCircle,
  Clock, Download, Sun, Moon, ChevronDown, Filter, Check, Loader2,
  DollarSign, Users, ChevronLeft, ChevronRight, Snowflake, FileText,
  Camera, Phone, Globe, MapPin, Briefcase, AlertTriangle, TrendingUp,
  TrendingDown, Upload, Mail, Building2, Hash, Lock,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
type Page = "login" | "register" | "dashboard" | "accounts" | "deposit" | "transfer" | "profile" | "admin";

// ─── Mock Data ────────────────────────────────────────────────────────────────
const monthlyActivity = [
  { month: "Jan", deposits: 8200, debits: 5100, transfers: 3200 },
  { month: "Feb", deposits: 9800, debits: 6200, transfers: 4100 },
  { month: "Mar", deposits: 7500, debits: 4800, transfers: 2900 },
  { month: "Apr", deposits: 11200, debits: 7300, transfers: 5600 },
  { month: "May", deposits: 10500, debits: 6800, transfers: 4300 },
  { month: "Jun", deposits: 13800, debits: 8900, transfers: 6200 },
  { month: "Jul", deposits: 12100, debits: 7600, transfers: 5100 },
];

const balanceTrend = [
  { d: "1", v: 41200 }, { d: "5", v: 43800 }, { d: "10", v: 42100 },
  { d: "15", v: 45200 }, { d: "20", v: 44800 }, { d: "25", v: 46900 }, { d: "30", v: 47832 },
];
const depositTrend = [
  { d: "1", v: 2100 }, { d: "5", v: 3800 }, { d: "10", v: 2900 },
  { d: "15", v: 5200 }, { d: "20", v: 4100 }, { d: "25", v: 6800 }, { d: "30", v: 8500 },
];
const debitTrend = [
  { d: "1", v: 1800 }, { d: "5", v: 2400 }, { d: "10", v: 1600 },
  { d: "15", v: 3100 }, { d: "20", v: 2700 }, { d: "25", v: 2200 }, { d: "30", v: 3850 },
];

const transactions = [
  { id: "TXN-8401", name: "Mercury Software Inc.", date: "Jul 12, 2026", ref: "REF-9284", amount: -2480.00, status: "completed" },
  { id: "TXN-8400", name: "Acme Corp Payroll", date: "Jul 11, 2026", ref: "REF-9283", amount: 8500.00, status: "completed" },
  { id: "TXN-8399", name: "Stripe Inc. Payout", date: "Jul 10, 2026", ref: "REF-9282", amount: 3240.50, status: "completed" },
  { id: "TXN-8398", name: "Amazon Web Services", date: "Jul 9, 2026", ref: "REF-9281", amount: -890.20, status: "pending" },
  { id: "TXN-8397", name: "Google Workspace", date: "Jul 8, 2026", ref: "REF-9280", amount: -420.00, status: "completed" },
  { id: "TXN-8396", name: "Vercel Pro Plan", date: "Jul 7, 2026", ref: "REF-9279", amount: -240.00, status: "failed" },
  { id: "TXN-8395", name: "Notion HQ Deposit", date: "Jul 6, 2026", ref: "REF-9278", amount: 1200.00, status: "completed" },
  { id: "TXN-8394", name: "Linear App License", date: "Jul 5, 2026", ref: "REF-9277", amount: -96.00, status: "completed" },
];

const adminUsers = [
  { id: "USR-001", name: "Alexandra Chen", email: "a.chen@company.com", phone: "+1 (415) 555-0192", uuid: "a1b2-c3d4-e5f6", kyc: "approved", joined: "Jan 15, 2026" },
  { id: "USR-002", name: "Marcus Rodriguez", email: "m.rodriguez@firm.io", phone: "+1 (628) 555-0147", uuid: "b2c3-d4e5-f6a7", kyc: "pending", joined: "Feb 3, 2026" },
  { id: "USR-003", name: "Priya Nair", email: "p.nair@ventures.co", phone: "+44 20 7946 0318", uuid: "c3d4-e5f6-a7b8", kyc: "approved", joined: "Mar 22, 2026" },
  { id: "USR-004", name: "James Okafor", email: "j.okafor@capital.net", phone: "+234 801 555 0193", uuid: "d4e5-f6a7-b8c9", kyc: "rejected", joined: "Apr 8, 2026" },
  { id: "USR-005", name: "Sofia Lindqvist", email: "s.lindqvist@nordic.se", phone: "+46 70 555 0127", uuid: "e5f6-a7b8-c9d0", kyc: "pending", joined: "May 19, 2026" },
  { id: "USR-006", name: "Kenji Yamamoto", email: "k.yamamoto@tokyo.jp", phone: "+81 90 5555 0184", uuid: "f6a7-b8c9-d0e1", kyc: "approved", joined: "Jun 1, 2026" },
];

// ─── Utilities ────────────────────────────────────────────────────────────────
function fmt(n: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(Math.abs(n));
}
function initials(name: string): string {
  return name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

// ─── Shared UI ────────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    completed: "bg-emerald-50 text-emerald-700 border-emerald-200",
    approved:  "bg-emerald-50 text-emerald-700 border-emerald-200",
    pending:   "bg-amber-50 text-amber-700 border-amber-200",
    failed:    "bg-red-50 text-red-600 border-red-200",
    rejected:  "bg-red-50 text-red-600 border-red-200",
  };
  const icons: Record<string, React.ReactNode> = {
    completed: <CheckCircle2 className="w-3 h-3" />,
    approved:  <CheckCircle2 className="w-3 h-3" />,
    pending:   <Clock className="w-3 h-3" />,
    failed:    <XCircle className="w-3 h-3" />,
    rejected:  <XCircle className="w-3 h-3" />,
  };
  const cls = styles[status] ?? "bg-slate-50 text-slate-600 border-slate-200";
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium border ${cls}`}>
      {icons[status]}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

function Sparkline({ data, color, gid }: { data: { v: number }[]; color: string; gid: string }) {
  return (
    <ResponsiveContainer width="100%" height={44}>
      <AreaChart data={data} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.25} />
            <stop offset="95%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={`url(#${gid})`} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

// ─── Login Page ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  const [email, setEmail] = useState("alex.chen@nexapay.com");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);

  function handleLogin() {
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 1800);
  }

  return (
    <div className="min-h-screen flex" style={{ background: "#F7F8FA" }}>
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-[52%] relative overflow-hidden flex-col justify-between p-12" style={{ background: "linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 45%, #4338ca 100%)" }}>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -left-32 w-[500px] h-[500px] rounded-full" style={{ background: "rgba(255,255,255,0.04)" }} />
          <div className="absolute top-1/3 -right-24 w-80 h-80 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }} />
          <div className="absolute -bottom-20 left-1/3 w-64 h-64 rounded-full" style={{ background: "rgba(99,102,241,0.25)" }} />
          <svg className="absolute bottom-0 right-0 w-72 h-72 opacity-10" viewBox="0 0 200 200" fill="none">
            <path d="M 0,100 C 0,44.8 44.8,0 100,0 C 155.2,0 200,44.8 200,100 C 200,155.2 155.2,200 100,200 C 44.8,200 0,155.2 0,100 Z" fill="white" />
          </svg>
        </div>

        {/* Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <span className="text-white font-bold text-xl tracking-tight">NexaPay</span>
        </div>

        {/* Card illustration */}
        <div className="relative z-10 flex flex-col items-center gap-6">
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="w-80 rounded-3xl p-7 shadow-2xl relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.06) 100%)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(12px)" }}
          >
            <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }} />
            <div className="flex justify-between items-start mb-8">
              <div>
                <p className="text-xs font-medium mb-0.5" style={{ color: "rgba(191,219,254,0.8)" }}>NexaPay</p>
                <p className="text-white font-bold text-base">Checking Account</p>
              </div>
              <svg width="44" height="28" viewBox="0 0 44 28" fill="none">
                <circle cx="16" cy="14" r="14" fill="rgba(255,255,255,0.35)" />
                <circle cx="28" cy="14" r="14" fill="rgba(255,255,255,0.2)" />
              </svg>
            </div>
            <div className="w-10 h-7 rounded-md mb-5 border flex items-center justify-center" style={{ background: "rgba(251,191,36,0.75)", borderColor: "rgba(253,230,138,0.5)" }}>
              <div className="w-6 h-4 rounded-sm" style={{ background: "rgba(253,230,138,0.45)", border: "1px solid rgba(253,230,138,0.3)" }} />
            </div>
            <p className="text-sm tracking-widest mb-5 font-mono" style={{ color: "rgba(255,255,255,0.75)" }}>•••• •••• •••• 4521</p>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-xs uppercase tracking-wider mb-0.5" style={{ color: "rgba(147,197,253,0.6)" }}>Card Holder</p>
                <p className="text-white font-semibold text-sm">Alexandra Chen</p>
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-wider mb-0.5" style={{ color: "rgba(147,197,253,0.6)" }}>Expires</p>
                <p className="text-white font-semibold text-sm">09/28</p>
              </div>
            </div>
          </motion.div>

          <div className="flex gap-4">
            <div className="rounded-2xl px-5 py-3 text-center" style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}>
              <p className="text-xs mb-1" style={{ color: "rgba(147,197,253,0.8)" }}>Available Balance</p>
              <p className="text-white font-bold text-xl">$47,832.50</p>
            </div>
            <div className="rounded-2xl px-5 py-3 text-center" style={{ background: "rgba(16,185,129,0.18)", border: "1px solid rgba(52,211,153,0.25)" }}>
              <p className="text-xs mb-1" style={{ color: "rgba(110,231,183,0.8)" }}>This Month</p>
              <p className="font-bold text-xl" style={{ color: "#6ee7b7" }}>+$8,540</p>
            </div>
          </div>
        </div>

        <div className="relative z-10">
          <h2 className="text-white text-2xl font-bold mb-2">Banking built for the modern era</h2>
          <p className="text-sm leading-relaxed" style={{ color: "rgba(147,197,253,0.75)" }}>Manage finances, move money, and track every transaction — elegantly, in one place.</p>
        </div>
      </div>

      {/* Right form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
          className="w-full max-w-md"
        >
          <div className="flex items-center gap-2.5 mb-10 lg:hidden">
            <div className="w-9 h-9 rounded-xl bg-blue-700 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-xl text-slate-900">NexaPay</span>
          </div>

          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Welcome back</h1>
            <p className="text-slate-500">Sign in to your NexaPay account to continue.</p>
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Email address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all text-sm"
                  style={{ "--tw-ring-color": "rgba(59,130,246,0.25)" } as React.CSSProperties}
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-sm font-semibold text-slate-700">Password</label>
                <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">Forgot password?</button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-11 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all text-sm"
                  placeholder="Enter your password"
                />
                <button
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setRemember(!remember)}
                className={`w-4.5 h-4.5 w-5 h-5 rounded flex items-center justify-center border-2 transition-all ${remember ? "bg-blue-600 border-blue-600" : "border-slate-300 bg-white"}`}
              >
                {remember && <Check className="w-3 h-3 text-white" />}
              </button>
              <span className="text-sm text-slate-600">Remember me for 30 days</span>
            </div>

            <motion.button
              onClick={handleLogin}
              disabled={loading}
              whileTap={{ scale: 0.98 }}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              style={{ boxShadow: "0 8px 24px rgba(29,78,216,0.3)" }}
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Signing in...</>
              ) : "Sign In"}
            </motion.button>
          </div>

          <p className="text-center text-sm text-slate-500 mt-7">
            {"Don't have an account? "}
            <button onClick={onRegister} className="text-blue-600 font-semibold hover:underline">Register Now</button>
          </p>
        </motion.div>
      </div>
    </div>
  );
}

// ─── Register Page ────────────────────────────────────────────────────────────
function RegisterPage({ onBack }: { onBack: () => void }) {
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", password: "", terms: false });
  const [loading, setLoading] = useState(false);

  function strength(p: string): number {
    if (!p) return 0;
    return [p.length >= 8, /[A-Z]/.test(p), /[0-9]/.test(p), /[^a-zA-Z0-9]/.test(p)].filter(Boolean).length;
  }
  const s = strength(form.password);
  const sLabel = ["", "Weak", "Fair", "Good", "Strong"][s];
  const sColor = ["", "#ef4444", "#f59e0b", "#eab308", "#10b981"][s];

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ background: "#F7F8FA" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-lg"
      >
        <div className="flex items-center gap-2.5 mb-7">
          <div className="w-9 h-9 rounded-xl bg-blue-700 flex items-center justify-center">
            <Building2 className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-xl text-slate-900">NexaPay</span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-8" style={{ boxShadow: "0 4px 24px rgba(15,23,42,0.06)" }}>
          <div className="mb-7">
            <h1 className="text-2xl font-bold text-slate-900 mb-1.5">Create your account</h1>
            <p className="text-slate-500 text-sm">Join thousands managing their finances with NexaPay.</p>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">First Name</label>
                <input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" placeholder="Alexandra" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">Last Name</label>
                <input value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" placeholder="Chen" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" placeholder="you@example.com" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Contact Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" placeholder="+1 (555) 000-0000" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" placeholder="Create a strong password" />
              </div>
              {form.password && (
                <div className="mt-2.5">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-1 flex-1 rounded-full transition-all duration-300"
                        style={{ background: i <= s ? sColor : "#E2E8F0" }} />
                    ))}
                  </div>
                  <p className="text-xs text-slate-500" style={{ color: s > 0 ? sColor : undefined }}>{sLabel} password</p>
                </div>
              )}
            </div>

            <div className="flex items-start gap-2.5 pt-1">
              <button onClick={() => setForm({ ...form, terms: !form.terms })}
                className={`mt-0.5 w-5 h-5 rounded flex items-center justify-center border-2 transition-all shrink-0 ${form.terms ? "bg-blue-600 border-blue-600" : "border-slate-300 bg-white"}`}>
                {form.terms && <Check className="w-3 h-3 text-white" />}
              </button>
              <p className="text-sm text-slate-600">
                I agree to the{" "}
                <button className="text-blue-600 font-semibold hover:underline">Terms of Service</button>
                {" and "}
                <button className="text-blue-600 font-semibold hover:underline">Privacy Policy</button>
              </p>
            </div>

            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={() => { setLoading(true); setTimeout(() => setLoading(false), 1500); }}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all flex items-center justify-center gap-2"
              style={{ boxShadow: "0 8px 24px rgba(29,78,216,0.3)" }}
            >
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Creating account...</> : "Create Account"}
            </motion.button>
          </div>

          <p className="text-center text-sm text-slate-500 mt-6">
            Already have an account?{" "}
            <button onClick={onBack} className="text-blue-600 font-semibold hover:underline">Sign In</button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", label: "Dashboard",          icon: LayoutDashboard },
  { id: "accounts",  label: "Accounts",            icon: CreditCard },
  { id: "transfer",  label: "Transfer Funds",       icon: ArrowLeftRight },
  { id: "deposit",   label: "Deposit / Withdraw",   icon: Wallet },
  { id: "profile",   label: "Edit Profile",         icon: User },
  { id: "admin",     label: "Admin Approvals",      icon: ShieldCheck },
];

function Sidebar({ page, onNavigate, collapsed, onToggle }: {
  page: Page; onNavigate: (p: Page) => void; collapsed: boolean; onToggle: () => void;
}) {
  return (
    <motion.aside
      animate={{ width: collapsed ? 70 : 240 }}
      transition={{ duration: 0.28, ease: [0.25, 0.1, 0.25, 1] }}
      className="h-screen bg-white border-r border-slate-100 flex flex-col shrink-0 overflow-hidden relative z-20"
      style={{ boxShadow: "1px 0 0 rgba(15,23,42,0.05)" }}
    >
      {/* Brand */}
      <div className="h-16 flex items-center px-4 border-b border-slate-100 gap-3 shrink-0">
        <div className="w-9 h-9 rounded-xl bg-blue-700 flex items-center justify-center shrink-0">
          <Building2 className="w-4 h-4 text-white" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -6 }}
              transition={{ duration: 0.15 }}
              className="font-bold text-slate-900 text-lg whitespace-nowrap"
            >
              NexaPay
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 px-2 space-y-0.5 overflow-hidden">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => onNavigate(item.id as Page)}
              whileTap={{ scale: 0.97 }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 text-sm font-medium relative ${
                active ? "bg-blue-50 text-blue-700" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"
              }`}
            >
              <Icon className={`w-[18px] h-[18px] shrink-0 ${active ? "text-blue-600" : ""}`} />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.12 }}
                    className="whitespace-nowrap"
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
              {active && (
                <motion.span
                  layoutId="nav-dot"
                  className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0"
                />
              )}
            </motion.button>
          );
        })}
      </nav>

      {/* Logout + collapse toggle */}
      <div className="px-2 pb-3 border-t border-slate-100 pt-2 space-y-0.5 shrink-0">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 transition-all">
          <LogOut className="w-[18px] h-[18px] shrink-0" />
          <AnimatePresence>
            {!collapsed && (
              <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.12 }} className="whitespace-nowrap">
                Logout
              </motion.span>
            )}
          </AnimatePresence>
        </button>
        <button onClick={onToggle} className="w-full flex items-center justify-center py-2 rounded-xl text-slate-400 hover:bg-slate-50 hover:text-slate-600 transition-all">
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>
    </motion.aside>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────
const PAGE_LABELS: Record<string, string> = {
  dashboard: "Dashboard", accounts: "Accounts", transfer: "Transfer Funds",
  deposit: "Deposit & Withdrawal", profile: "Edit Profile", admin: "Admin Approvals",
};

function Header({ page, darkMode, onToggleDark }: { page: Page; darkMode: boolean; onToggleDark: () => void }) {
  const [notifOpen, setNotifOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);

  return (
    <header className="h-16 bg-white border-b border-slate-100 flex items-center px-6 gap-4 sticky top-0 z-10 shrink-0">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-0.5">
          <span className="text-blue-600 font-medium">NexaPay</span>
          <span>/</span>
          <span className="text-slate-600 font-medium">{PAGE_LABELS[page]}</span>
        </div>
        <h1 className="text-base font-bold text-slate-900 leading-none">{PAGE_LABELS[page]}</h1>
      </div>

      <div className="relative hidden md:flex">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          placeholder="Search transactions..."
          className="pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-blue-500 w-52 transition-all"
        />
      </div>

      <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-xs font-medium text-emerald-700 whitespace-nowrap">All Systems Operational</span>
      </div>

      <button onClick={onToggleDark}
        className="w-9 h-9 rounded-xl border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:bg-slate-50 transition-all">
        {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
      </button>

      {/* Notifications */}
      <div className="relative">
        <button onClick={() => { setNotifOpen(!notifOpen); setUserOpen(false); }}
          className="w-9 h-9 rounded-xl border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:bg-slate-50 transition-all relative">
          <Bell className="w-4 h-4" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 border-2 border-white" />
        </button>
        <AnimatePresence>
          {notifOpen && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-12 w-80 bg-white rounded-2xl border border-slate-100 overflow-hidden z-50"
              style={{ boxShadow: "0 16px 48px rgba(15,23,42,0.12)" }}
            >
              <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-900">Notifications</span>
                <span className="text-xs text-blue-600 font-medium cursor-pointer hover:underline">Mark all read</span>
              </div>
              {[
                { msg: "Transfer of $2,480 processed successfully", time: "2 min ago", dot: "#10b981" },
                { msg: "KYC verification is pending review", time: "1 hour ago", dot: "#f59e0b" },
                { msg: "New login from San Francisco, CA", time: "3 hours ago", dot: "#3b82f6" },
              ].map((n, i) => (
                <div key={i} className="px-4 py-3 hover:bg-slate-50 cursor-pointer flex gap-3 border-b border-slate-50 last:border-0">
                  <span className="w-2 h-2 rounded-full shrink-0 mt-1.5" style={{ background: n.dot }} />
                  <div>
                    <p className="text-sm text-slate-800">{n.msg}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{n.time}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* User */}
      <div className="relative">
        <button onClick={() => { setUserOpen(!userOpen); setNotifOpen(false); }}
          className="flex items-center gap-2.5 pl-1 pr-3 py-1 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
            style={{ background: "linear-gradient(135deg, #3b82f6, #4f46e5)" }}>
            AC
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-semibold text-slate-900 leading-tight">Alexandra Chen</p>
            <p className="text-xs text-slate-400">Premium Account</p>
          </div>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
        </button>
        <AnimatePresence>
          {userOpen && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-12 w-52 bg-white rounded-2xl border border-slate-100 overflow-hidden z-50"
              style={{ boxShadow: "0 16px 48px rgba(15,23,42,0.12)" }}
            >
              <div className="px-4 py-3 border-b border-slate-100">
                <p className="font-semibold text-sm text-slate-900">Alexandra Chen</p>
                <p className="text-xs text-slate-400">a.chen@nexapay.com</p>
              </div>
              {["My Profile", "Account Settings", "Security", "Help & Support"].map((item) => (
                <button key={item} className="w-full text-left px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 transition-all">{item}</button>
              ))}
              <div className="border-t border-slate-100 p-2">
                <button className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-xl transition-all flex items-center gap-2">
                  <LogOut className="w-4 h-4" /> Sign out
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
function DashboardPage() {
  const [balanceVisible, setBalanceVisible] = useState(true);

  const cards = [
    { title: "Available Balance", value: "$47,832.50", sub: "Account •••• 4521", trend: "+12.5% this month", up: true, data: balanceTrend, color: "#3b82f6", hero: true },
    { title: "Total Deposits",    value: "$89,240.00",  sub: "Jul 2026",          trend: "+8.2% vs last month", up: true,  data: depositTrend, color: "#10b981", hero: false },
    { title: "Total Debits",      value: "$41,407.50",  sub: "Jul 2026",          trend: "+3.1% vs last month", up: false, data: debitTrend,   color: "#ef4444", hero: false },
    { title: "Monthly Savings",   value: "$6,420.00",   sub: "Auto-saving active", trend: "+18.4% vs last month", up: true, data: depositTrend, color: "#8b5cf6", hero: false },
  ];

  return (
    <div className="p-8 space-y-7">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Good morning, Alexandra 👋</h2>
        <p className="text-slate-500 text-sm mt-1">Financial overview for July 12, 2026.</p>
      </div>

      {/* Hero cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
        {cards.map((c, i) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.35 }}
            whileHover={{ y: -3, transition: { duration: 0.2 } }}
            className={`rounded-2xl p-5 overflow-hidden relative ${c.hero ? "text-white" : "bg-white border border-slate-100"}`}
            style={c.hero ? { background: "linear-gradient(135deg, #1e40af 0%, #1d4ed8 50%, #4338ca 100%)", boxShadow: "0 12px 36px rgba(29,78,216,0.28)" } : { boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}
          >
            {c.hero && (
              <>
                <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }} />
                <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }} />
              </>
            )}
            <div className="relative">
              <div className="flex items-center justify-between mb-3">
                <p className={`text-xs font-semibold uppercase tracking-wider ${c.hero ? "text-blue-200" : "text-slate-400"}`}>{c.title}</p>
                {c.hero && (
                  <button onClick={() => setBalanceVisible(!balanceVisible)} className="text-white/60 hover:text-white transition-colors">
                    {balanceVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                )}
              </div>
              <p className={`text-2xl font-bold mb-1 ${c.hero ? "text-white" : "text-slate-900"}`}>
                {c.hero ? (balanceVisible ? c.value : "••••••") : c.value}
              </p>
              <p className={`text-xs mb-3 ${c.hero ? "text-blue-200/70" : "text-slate-400"}`}>{c.sub}</p>
              {!c.hero && <div className="mb-3"><Sparkline data={c.data} color={c.color} gid={`sp-${i}`} /></div>}
              <div className={`flex items-center gap-1 text-xs font-medium ${c.hero ? "text-blue-200" : c.up ? "text-emerald-600" : "text-red-500"}`}>
                {c.up ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                {c.trend}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Chart + Transactions */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Bar chart */}
        <div className="xl:col-span-3 bg-white rounded-2xl border border-slate-100 p-6" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="font-semibold text-slate-900">Activity Statistics</h3>
              <p className="text-sm text-slate-400 mt-0.5">Monthly breakdown — 2026</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              {[["#3b82f6","Deposits"],["#f87171","Debits"],["#a78bfa","Transfers"]].map(([clr, lbl]) => (
                <span key={lbl} className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: clr }} />
                  {lbl}
                </span>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyActivity} barSize={9} barCategoryGap="32%">
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: "12px", fontSize: "12px", boxShadow: "0 8px 32px rgba(0,0,0,0.08)" }}
                formatter={(v: number) => [`$${v.toLocaleString()}`, ""]}
              />
              <Bar dataKey="deposits" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="debits" fill="#f87171" radius={[4, 4, 0, 0]} />
              <Bar dataKey="transfers" fill="#a78bfa" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Transactions */}
        <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-100 flex flex-col" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-slate-900">Recent Transactions</h3>
              <p className="text-xs text-slate-400 mt-0.5">Latest activity</p>
            </div>
            <button className="text-xs text-blue-600 font-medium hover:underline">View all</button>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-slate-50">
            {transactions.map((tx, i) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                className="flex items-center gap-3 px-5 py-3.5 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${tx.amount > 0 ? "bg-emerald-100 text-emerald-700" : "bg-red-50 text-red-500"}`}>
                  {tx.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{tx.name}</p>
                  <p className="text-xs text-slate-400">{tx.date} · {tx.ref}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className={`text-sm font-semibold ${tx.amount > 0 ? "text-emerald-600" : "text-slate-900"}`}>
                    {tx.amount > 0 ? "+" : "−"}{fmt(tx.amount)}
                  </p>
                  <StatusBadge status={tx.status} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Accounts Page ────────────────────────────────────────────────────────────
function AccountsPage() {
  const [search, setSearch] = useState("");
  const [pg, setPg] = useState(1);
  const filtered = transactions.filter(
    (tx) => tx.name.toLowerCase().includes(search.toLowerCase()) || tx.ref.includes(search)
  );

  return (
    <div className="p-8">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left */}
        <div className="lg:col-span-2 space-y-5">
          {/* Glass banking card */}
          <div className="relative rounded-2xl p-7 overflow-hidden" style={{ background: "linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 55%, #312e81 100%)", boxShadow: "0 20px 60px rgba(29,78,216,0.3)", aspectRatio: "1.586" }}>
            <div className="absolute -top-12 -right-12 w-44 h-44 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }} />
            <div className="absolute -bottom-10 -left-10 w-36 h-36 rounded-full" style={{ background: "rgba(99,102,241,0.2)" }} />
            <div className="absolute top-6 right-12 w-16 h-16 rounded-full border" style={{ borderColor: "rgba(255,255,255,0.08)" }} />

            <div className="relative flex flex-col h-full justify-between">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider mb-0.5" style={{ color: "rgba(147,197,253,0.75)" }}>NexaPay Bank</p>
                  <p className="text-white font-bold text-base">Checking Account</p>
                </div>
                <svg width="44" height="28" viewBox="0 0 44 28" fill="none">
                  <circle cx="16" cy="14" r="14" fill="rgba(255,255,255,0.35)" />
                  <circle cx="28" cy="14" r="14" fill="rgba(255,255,255,0.2)" />
                </svg>
              </div>

              <div>
                <div className="w-10 h-7 rounded-md mb-4 flex items-center justify-center" style={{ background: "rgba(251,191,36,0.8)", border: "1px solid rgba(253,230,138,0.5)" }}>
                  <div className="w-6 h-4 rounded-sm" style={{ background: "rgba(253,230,138,0.5)" }} />
                </div>
                <p className="font-mono text-sm tracking-[0.2em] mb-5" style={{ color: "rgba(255,255,255,0.8)" }}>•••• •••• •••• 4521</p>
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-xs uppercase tracking-wider mb-0.5" style={{ color: "rgba(147,197,253,0.6)" }}>Card Holder</p>
                    <p className="text-white font-semibold text-sm">Alexandra Chen</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs uppercase tracking-wider mb-0.5" style={{ color: "rgba(147,197,253,0.6)" }}>Expires</p>
                    <p className="text-white font-semibold text-sm">09/28</p>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t flex items-center justify-between" style={{ borderColor: "rgba(255,255,255,0.12)" }}>
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full" style={{ background: "rgba(16,185,129,0.2)", color: "#6ee7b7" }}>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Active
                  </span>
                  <p className="text-white font-bold text-lg">$47,832.50</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <h3 className="font-semibold text-slate-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: XCircle, label: "Close Account", cls: "text-red-500 bg-red-50 hover:bg-red-100" },
                { icon: Snowflake, label: "Freeze Card", cls: "text-blue-600 bg-blue-50 hover:bg-blue-100" },
                { icon: Download, label: "Statement", cls: "text-emerald-600 bg-emerald-50 hover:bg-emerald-100" },
              ].map((a) => (
                <button key={a.label} className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${a.cls}`}>
                  <a.icon className="w-5 h-5" />
                  <span className="text-xs font-medium text-center leading-tight">{a.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Account details */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <h3 className="font-semibold text-slate-900 mb-4">Account Details</h3>
            <div className="space-y-0">
              {[
                { l: "Account Number", v: "•••• •••• 4521" },
                { l: "Routing Number", v: "021000021" },
                { l: "Account Type", v: "Personal Checking" },
                { l: "Currency", v: "USD — US Dollar" },
                { l: "SWIFT / BIC", v: "NXAPUS33XXX" },
              ].map((item) => (
                <div key={item.l} className="flex items-center justify-between py-2.5 border-b border-slate-50 last:border-0">
                  <span className="text-xs text-slate-400">{item.l}</span>
                  <span className="text-sm text-slate-800 font-medium font-mono">{item.v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Statement */}
        <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-100 flex flex-col" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
          <div className="p-5 border-b border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-slate-900">Account Statement</h3>
                <p className="text-xs text-slate-400 mt-0.5">All transactions for this account</p>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1.5 text-xs font-medium text-slate-600 border border-slate-200 px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-all">
                  <Filter className="w-3.5 h-3.5" /> Filter
                </button>
                <button className="flex items-center gap-1.5 text-xs font-medium text-slate-600 border border-slate-200 px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-all">
                  <Download className="w-3.5 h-3.5" /> Export
                </button>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or reference..."
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" />
            </div>
          </div>

          <div className="overflow-auto flex-1">
            <table className="w-full text-sm">
              <thead className="sticky top-0">
                <tr className="bg-slate-50 border-b border-slate-100">
                  {["Date", "Reference", "Description", "Amount", "Status"].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition-colors cursor-pointer">
                    <td className="px-4 py-3.5 text-slate-500 text-xs whitespace-nowrap">{tx.date}</td>
                    <td className="px-4 py-3.5 font-mono text-xs text-slate-400">{tx.ref}</td>
                    <td className="px-4 py-3.5 text-slate-900 font-medium max-w-[160px] truncate">{tx.name}</td>
                    <td className={`px-4 py-3.5 font-semibold whitespace-nowrap ${tx.amount > 0 ? "text-emerald-600" : "text-slate-900"}`}>
                      {tx.amount > 0 ? "+" : "−"}{fmt(tx.amount)}
                    </td>
                    <td className="px-4 py-3.5"><StatusBadge status={tx.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 border-t border-slate-100 flex items-center justify-between">
            <p className="text-xs text-slate-400">Showing {filtered.length} of {transactions.length} transactions</p>
            <div className="flex items-center gap-1.5">
              <button onClick={() => setPg(Math.max(1, pg - 1))} disabled={pg === 1}
                className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-50 disabled:opacity-40 transition-all">
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              {[1, 2, 3].map((p) => (
                <button key={p} onClick={() => setPg(p)}
                  className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${pg === p ? "bg-blue-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPg(Math.min(3, pg + 1))}
                className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-50 transition-all">
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Deposit / Withdraw Page ──────────────────────────────────────────────────
function DepositPage() {
  const [tab, setTab] = useState<"deposit" | "withdraw">("deposit");
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const lastAmount = amount;

  function submit() { setLoading(true); setTimeout(() => { setLoading(false); setSuccess(true); }, 2000); }

  if (success) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[55vh]">
        <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-2xl border border-slate-100 p-10 text-center max-w-sm w-full"
          style={{ boxShadow: "0 16px 48px rgba(15,23,42,0.08)" }}>
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.15, type: "spring", stiffness: 220 }}
            className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-5">
            <Check className="w-8 h-8 text-emerald-600" />
          </motion.div>
          <h3 className="text-xl font-bold text-slate-900 mb-1">Transaction Successful</h3>
          <p className="text-slate-500 text-sm mb-2">{tab === "deposit" ? "Deposit" : "Withdrawal"} of</p>
          <p className="text-3xl font-bold text-slate-900 mb-1">${parseFloat(lastAmount || "0").toFixed(2)}</p>
          <p className="text-slate-400 text-sm mb-7">processed successfully. Funds will reflect within minutes.</p>
          <button onClick={() => { setSuccess(false); setAmount(""); setMemo(""); }}
            className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all">
            New Transaction
          </button>
        </motion.div>
      </div>
    );
  }

  const parsed = parseFloat(amount);
  const valid = amount && !isNaN(parsed) && parsed > 0;

  return (
    <div className="p-8">
      <div className="max-w-lg mx-auto space-y-5">
        <div className="rounded-2xl p-5 text-white" style={{ background: "linear-gradient(135deg, #1e40af, #1d4ed8, #4338ca)", boxShadow: "0 12px 36px rgba(29,78,216,0.28)" }}>
          <p className="text-sm font-medium mb-1" style={{ color: "rgba(147,197,253,0.85)" }}>Available Balance</p>
          <p className="text-3xl font-bold">$47,832.50</p>
          <p className="text-xs mt-1" style={{ color: "rgba(147,197,253,0.65)" }}>Checking Account •••• 4521</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-6" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
          <div className="flex bg-slate-100 rounded-xl p-1 mb-6">
            {(["deposit", "withdraw"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === t ? "bg-white shadow-sm text-slate-900" : "text-slate-500 hover:text-slate-700"}`}>
                {t === "deposit" ? "Deposit" : "Withdraw"}
              </button>
            ))}
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Amount (USD)</label>
              <div className="relative">
                <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 text-xl font-bold focus:outline-none focus:ring-2 focus:border-blue-500 transition-all"
                  placeholder="0.00" />
              </div>
              <div className="flex gap-2 mt-3">
                {["500", "1000", "2500", "5000"].map((v) => (
                  <button key={v} onClick={() => setAmount(v)}
                    className="flex-1 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-all">
                    ${parseInt(v).toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Memo (Optional)</label>
              <textarea value={memo} onChange={(e) => setMemo(e.target.value)} rows={2}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all resize-none"
                placeholder="Add a note..." />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Upload Receipt (Optional)</label>
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-5 text-center hover:border-blue-300 hover:bg-blue-50/30 transition-all cursor-pointer">
                <Upload className="w-5 h-5 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Drop file or <span className="text-blue-600 font-medium">browse</span></p>
                <p className="text-xs text-slate-400 mt-0.5">PNG, JPG, PDF up to 10 MB</p>
              </div>
            </div>

            {valid && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
                className="bg-slate-50 rounded-xl p-4 space-y-2.5">
                {[
                  { l: `${tab === "deposit" ? "Deposit" : "Withdrawal"} Amount`, v: `$${parsed.toFixed(2)}` },
                  { l: "Processing Fee", v: "Free", green: true },
                ].map((r) => (
                  <div key={r.l} className="flex justify-between text-sm">
                    <span className="text-slate-500">{r.l}</span>
                    <span className={`font-medium ${r.green ? "text-emerald-600" : "text-slate-900"}`}>{r.v}</span>
                  </div>
                ))}
                <div className="h-px bg-slate-200" />
                <div className="flex justify-between text-sm font-bold">
                  <span className="text-slate-900">Total</span>
                  <span className="text-slate-900">${parsed.toFixed(2)}</span>
                </div>
              </motion.div>
            )}

            <motion.button whileTap={{ scale: 0.98 }} onClick={submit} disabled={!valid || loading}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold transition-all flex items-center justify-center gap-2"
              style={{ boxShadow: valid ? "0 8px 24px rgba(29,78,216,0.3)" : "none" }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Processing...</> : `${tab === "deposit" ? "Deposit" : "Withdraw"} Funds`}
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Transfer Page ────────────────────────────────────────────────────────────
function TransferPage() {
  const [form, setForm] = useState({ acct: "", name: "", amount: "", remarks: "" });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  function transfer() { setLoading(true); setTimeout(() => { setLoading(false); setSuccess(true); }, 2500); }

  if (success) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[55vh]">
        <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-2xl border border-slate-100 p-10 text-center max-w-sm w-full"
          style={{ boxShadow: "0 16px 48px rgba(15,23,42,0.08)" }}>
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.15, type: "spring", stiffness: 220 }}
            className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-5">
            <Check className="w-8 h-8 text-emerald-600" />
          </motion.div>
          <h3 className="text-xl font-bold text-slate-900 mb-1">Transfer Successful!</h3>
          <p className="text-slate-500 text-sm mb-2">You sent</p>
          <p className="text-3xl font-bold text-slate-900">${parseFloat(form.amount || "0").toFixed(2)}</p>
          <p className="text-slate-400 text-sm my-1">to</p>
          <p className="font-semibold text-slate-800 mb-7">{form.name || "Recipient"}</p>
          <button onClick={() => { setSuccess(false); setForm({ acct: "", name: "", amount: "", remarks: "" }); }}
            className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all">
            New Transfer
          </button>
        </motion.div>
      </div>
    );
  }

  const parsedAmt = parseFloat(form.amount);
  const valid = !isNaN(parsedAmt) && parsedAmt > 0;
  const fee = valid ? (parsedAmt * 0.005).toFixed(2) : "0.00";
  const total = valid ? (parsedAmt + parseFloat(fee)).toFixed(2) : "0.00";

  return (
    <div className="p-8">
      <div className="max-w-2xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-5">
          {/* Form */}
          <div className="md:col-span-3 bg-white rounded-2xl border border-slate-100 p-6 space-y-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">From</p>
              <div className="flex items-center gap-3 bg-blue-50 rounded-xl p-3.5">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0"
                  style={{ background: "linear-gradient(135deg, #3b82f6, #4f46e5)" }}>
                  AC
                </div>
                <div>
                  <p className="font-semibold text-slate-900 text-sm">Alexandra Chen</p>
                  <p className="text-xs text-slate-500">•••• 4521 · $47,832.50 available</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-slate-100" />
              <ArrowDownLeft className="w-5 h-5 text-slate-300" />
              <div className="flex-1 h-px bg-slate-100" />
            </div>

            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">To</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Account Number</label>
                  <div className="relative">
                    <Hash className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input value={form.acct} onChange={(e) => setForm({ ...form, acct: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all text-sm"
                      placeholder="Enter account number" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Beneficiary Name</label>
                  <div className="relative">
                    <Users className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all text-sm"
                      placeholder="Full name of recipient" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Amount (USD)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 text-xl font-bold focus:outline-none focus:ring-2 focus:border-blue-500 transition-all"
                      placeholder="0.00" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Remarks</label>
                  <input value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all"
                    placeholder="What is this transfer for?" />
                </div>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className="md:col-span-2 space-y-4">
            <div className="bg-white rounded-2xl border border-slate-100 p-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
              <h3 className="font-semibold text-slate-900 mb-4">Transfer Summary</h3>
              <div className="space-y-3">
                {[
                  { l: "To", v: form.name || "—" },
                  { l: "Account", v: form.acct ? `•••• ${form.acct.slice(-4)}` : "—" },
                  { l: "Amount", v: valid ? `$${parsedAmt.toFixed(2)}` : "—" },
                  { l: "Transfer Fee (0.5%)", v: `$${fee}` },
                ].map((r) => (
                  <div key={r.l} className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">{r.l}</span>
                    <span className="font-medium text-slate-900 text-right max-w-[140px] truncate">{r.v}</span>
                  </div>
                ))}
                <div className="h-px bg-slate-100" />
                <div className="flex justify-between text-sm font-bold">
                  <span className="text-slate-900">Total Deducted</span>
                  <span className="text-slate-900">${total}</span>
                </div>
              </div>
            </div>

            <motion.button whileTap={{ scale: 0.98 }} onClick={transfer}
              disabled={!form.acct || !valid || loading}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold transition-all flex items-center justify-center gap-2"
              style={{ boxShadow: "0 8px 24px rgba(29,78,216,0.3)" }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Processing...</> : "Confirm Transfer"}
            </motion.button>

            <div className="flex gap-2.5 bg-amber-50 border border-amber-200 rounded-xl p-3.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700 leading-relaxed">Verify beneficiary details before confirming. Transfers cannot be reversed once processed.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Profile / KYC Page ───────────────────────────────────────────────────────
function ProfilePage() {
  const progress = 75;
  const [form, setForm] = useState({
    firstName: "Alexandra", lastName: "Chen", phone: "+1 (415) 555-0192",
    nationality: "United States", gender: "Female", marital: "Single",
    occupation: "Software Engineer", address: "123 Market St, San Francisco, CA 94105",
  });
  const [saved, setSaved] = useState(false);

  function save() { setSaved(true); setTimeout(() => setSaved(false), 2200); }

  const fields = [
    { l: "First Name", k: "firstName", icon: Users, span: false },
    { l: "Last Name", k: "lastName", icon: Users, span: false },
    { l: "Contact Number", k: "phone", icon: Phone, span: false },
    { l: "Nationality", k: "nationality", icon: Globe, span: false },
    { l: "Gender", k: "gender", icon: Users, span: false },
    { l: "Marital Status", k: "marital", icon: Users, span: false },
    { l: "Occupation", k: "occupation", icon: Briefcase, span: true },
    { l: "Address", k: "address", icon: MapPin, span: true, textarea: true },
  ];

  return (
    <div className="p-8 space-y-6">
      {/* Progress */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 flex items-center gap-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
        <div className="relative w-14 h-14 shrink-0">
          <svg className="w-14 h-14 -rotate-90" viewBox="0 0 56 56">
            <circle cx="28" cy="28" r="22" fill="none" stroke="#F1F5F9" strokeWidth="5" />
            <circle cx="28" cy="28" r="22" fill="none" stroke="#1d4ed8" strokeWidth="5"
              strokeDasharray={`${2 * Math.PI * 22}`}
              strokeDashoffset={`${2 * Math.PI * 22 * (1 - progress / 100)}`}
              strokeLinecap="round" />
          </svg>
          <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-900">{progress}%</span>
        </div>
        <div className="flex-1">
          <p className="font-semibold text-slate-900">KYC Profile Completion</p>
          <p className="text-sm text-slate-500 mt-0.5">Complete your verification to unlock all premium features.</p>
          <div className="h-1.5 bg-slate-100 rounded-full mt-3 overflow-hidden">
            <motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 1, ease: "easeOut" }}
              className="h-full rounded-full" style={{ background: "linear-gradient(90deg, #1d4ed8, #4f46e5)" }} />
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-full shrink-0">
          <Clock className="w-3.5 h-3.5 text-amber-600" />
          <span className="text-xs font-medium text-amber-700">KYC Pending</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left column */}
        <div className="space-y-5">
          {/* Photo */}
          <div className="bg-white rounded-2xl border border-slate-100 p-6 text-center" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <div className="relative inline-block mb-4">
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-white text-3xl font-bold"
                style={{ background: "linear-gradient(135deg, #3b82f6, #4f46e5)" }}>
                AC
              </div>
              <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center">
                <Camera className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
            <p className="font-semibold text-slate-900">Alexandra Chen</p>
            <p className="text-sm text-slate-400 mt-0.5">Premium Account · ID USR-001</p>
            <button className="mt-4 w-full py-2 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-all">
              Change Photo
            </button>
          </div>

          {/* Documents */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <h3 className="font-semibold text-slate-900 mb-4">KYC Documents</h3>
            <div className="space-y-2.5">
              {[
                { l: "Government ID", s: "approved" },
                { l: "Passport", s: "pending" },
                { l: "Driver License", s: "missing" },
              ].map((doc) => (
                <div key={doc.l} className="flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:bg-slate-50 transition-all cursor-pointer">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <span className="text-sm font-medium text-slate-700">{doc.l}</span>
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    doc.s === "approved" ? "bg-emerald-50 text-emerald-700" :
                    doc.s === "pending" ? "bg-amber-50 text-amber-700" :
                    "bg-slate-100 text-slate-500"
                  }`}>
                    {doc.s === "missing" ? "+ Upload" : doc.s === "pending" ? "In Review" : "Verified"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-100 p-6" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
          <h3 className="font-semibold text-slate-900 mb-6">Personal Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {fields.map((f) => (
              <div key={f.k} className={f.span ? "sm:col-span-2" : ""}>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">{f.l}</label>
                {f.textarea ? (
                  <div className="relative">
                    <f.icon className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    <textarea
                      value={form[f.k as keyof typeof form]}
                      onChange={(e) => setForm({ ...form, [f.k]: e.target.value })}
                      rows={2}
                      className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all resize-none"
                    />
                  </div>
                ) : (
                  <div className="relative">
                    <f.icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      value={form[f.k as keyof typeof form]}
                      onChange={(e) => setForm({ ...form, [f.k]: e.target.value })}
                      className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:border-blue-500 transition-all"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-7 flex items-center gap-3">
            <motion.button whileTap={{ scale: 0.98 }} onClick={save}
              className={`px-6 py-3 rounded-xl font-semibold text-sm transition-all flex items-center gap-2 ${saved ? "bg-emerald-600 hover:bg-emerald-700" : "bg-blue-600 hover:bg-blue-700"} text-white`}
              style={{ boxShadow: "0 8px 24px rgba(29,78,216,0.25)" }}>
              {saved ? <><Check className="w-4 h-4" /> Saved!</> : "Save Profile"}
            </motion.button>
            <button className="px-6 py-3 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition-all">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Admin Page ───────────────────────────────────────────────────────────────
function AdminPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [statuses, setStatuses] = useState<Record<string, string>>({});
  const [confirm, setConfirm] = useState<{ user: typeof adminUsers[0]; action: "approve" | "reject" } | null>(null);

  const filtered = adminUsers.filter((u) => {
    const kycNow = statuses[u.id] || u.kyc;
    return (u.name.toLowerCase().includes(search.toLowerCase()) || u.email.includes(search)) &&
      (filter === "all" || kycNow === filter);
  });

  function act(user: typeof adminUsers[0], action: "approve" | "reject") {
    setStatuses((s) => ({ ...s, [user.id]: action === "approve" ? "approved" : "rejected" }));
    setConfirm(null);
  }

  const stats = [
    { l: "Total Users", v: adminUsers.length, icon: Users, cls: "text-blue-600 bg-blue-50" },
    { l: "Approved", v: adminUsers.filter((u) => (statuses[u.id] || u.kyc) === "approved").length, icon: CheckCircle2, cls: "text-emerald-600 bg-emerald-50" },
    { l: "Pending", v: adminUsers.filter((u) => (statuses[u.id] || u.kyc) === "pending").length, icon: Clock, cls: "text-amber-600 bg-amber-50" },
    { l: "Rejected", v: adminUsers.filter((u) => (statuses[u.id] || u.kyc) === "rejected").length, icon: XCircle, cls: "text-red-500 bg-red-50" },
  ];

  return (
    <div className="p-8 space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <motion.div key={s.l} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-slate-100 p-4 flex items-center gap-3"
            style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${s.cls}`}>
              <s.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900">{s.v}</p>
              <p className="text-xs text-slate-400">{s.l}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: "0 2px 12px rgba(15,23,42,0.04)" }}>
        <div className="p-5 border-b border-slate-100 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search users..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-blue-500 transition-all" />
          </div>
          <div className="flex gap-1.5">
            {["all", "pending", "approved", "rejected"].map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === f ? "bg-blue-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                {["User", "Email", "Phone", "UUID", "KYC Status", "Joined", "Actions"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((user, i) => {
                const kycNow = statuses[user.id] || user.kyc;
                return (
                  <motion.tr key={user.id} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                    className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                          style={{ background: "linear-gradient(135deg, #3b82f6, #4f46e5)" }}>
                          {initials(user.name)}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900 whitespace-nowrap">{user.name}</p>
                          <p className="text-xs text-slate-400">{user.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-slate-600 text-xs">{user.email}</td>
                    <td className="px-4 py-4 text-slate-600 text-xs whitespace-nowrap">{user.phone}</td>
                    <td className="px-4 py-4 font-mono text-xs text-slate-400">{user.uuid}</td>
                    <td className="px-4 py-4"><StatusBadge status={kycNow} /></td>
                    <td className="px-4 py-4 text-slate-500 text-xs whitespace-nowrap">{user.joined}</td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        {kycNow === "pending" && (
                          <>
                            <button onClick={() => setConfirm({ user, action: "approve" })}
                              className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-medium hover:bg-emerald-100 border border-emerald-200 transition-all">
                              Approve
                            </button>
                            <button onClick={() => setConfirm({ user, action: "reject" })}
                              className="px-3 py-1.5 rounded-lg bg-red-50 text-red-600 text-xs font-medium hover:bg-red-100 border border-red-200 transition-all">
                              Reject
                            </button>
                          </>
                        )}
                        <button className="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:bg-slate-50 transition-all">
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-slate-100 flex items-center justify-between">
          <p className="text-xs text-slate-400">Showing {filtered.length} of {adminUsers.length} users</p>
          <div className="flex items-center gap-1.5">
            {[1, 2, 3].map((p) => (
              <button key={p} className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${p === 1 ? "bg-blue-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>{p}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(15,23,42,0.45)", backdropFilter: "blur(4px)" }}
            onClick={() => setConfirm(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="bg-white rounded-2xl p-7 max-w-sm w-full"
              style={{ boxShadow: "0 24px 80px rgba(15,23,42,0.18)" }}
              onClick={(e) => e.stopPropagation()}>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${confirm.action === "approve" ? "bg-emerald-100" : "bg-red-100"}`}>
                {confirm.action === "approve"
                  ? <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                  : <XCircle className="w-6 h-6 text-red-600" />}
              </div>
              <h3 className="text-lg font-bold text-slate-900 text-center mb-1.5">
                {confirm.action === "approve" ? "Approve KYC?" : "Reject KYC?"}
              </h3>
              <p className="text-sm text-slate-500 text-center mb-6">
                This will {confirm.action} the KYC verification for{" "}
                <strong className="text-slate-800">{confirm.user.name}</strong>. This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button onClick={() => setConfirm(null)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition-all">
                  Cancel
                </button>
                <button onClick={() => act(confirm.user, confirm.action)}
                  className={`flex-1 py-2.5 rounded-xl text-white text-sm font-semibold transition-all ${confirm.action === "approve" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-red-600 hover:bg-red-700"}`}>
                  {confirm.action === "approve" ? "Approve" : "Reject"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<Page>("login");
  const [loggedIn, setLoggedIn] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  if (!loggedIn) {
    if (page === "register") return <RegisterPage onBack={() => setPage("login")} />;
    return (
      <LoginPage
        onLogin={() => { setLoggedIn(true); setPage("dashboard"); }}
        onRegister={() => setPage("register")}
      />
    );
  }

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <DashboardPage />;
      case "accounts":  return <AccountsPage />;
      case "deposit":   return <DepositPage />;
      case "transfer":  return <TransferPage />;
      case "profile":   return <ProfilePage />;
      case "admin":     return <AdminPage />;
      default:          return <DashboardPage />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "#F7F8FA" }}>
      <Sidebar page={page} onNavigate={setPage} collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} />
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <Header page={page} darkMode={darkMode} onToggleDark={() => setDarkMode(!darkMode)} />
        <main className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: [0.25, 0.1, 0.25, 1] }}
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
